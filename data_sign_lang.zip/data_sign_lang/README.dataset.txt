# ISL words > 2023-04-14 12:56pm
https://universe.roboflow.com/indian-sign-language-detection/isl-words

Provided by a Roboflow user
License: CC BY 4.0

